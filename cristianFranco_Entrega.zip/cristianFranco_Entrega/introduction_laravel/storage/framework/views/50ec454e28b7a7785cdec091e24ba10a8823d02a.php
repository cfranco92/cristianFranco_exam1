<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e($data["user"]["name"]); ?>

                    </div>
                    <div class="card-body">
                        <img src="<?php echo e($data["user"]["icon"]); ?>" alt="User icon" style="width:100px;height:100px;" class="center"> <br>
                        <b>Name:</b> <?php echo e($data["user"]["name"]); ?> <br>
                        <b>Email:</b> <?php echo e($data["user"]["email"]); ?> <br>
                        <b>City:</b> <?php echo e($data["user"]["city"]); ?> <br>
                        <b>Phone:</b> <?php echo e($data["user"]["phone"]); ?> <br><br>
                        <td>
                            <form action="<?php echo e(route('user.destroy', $data["user"])); ?>" method="POST" class="center">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input
                                    type="submit"
                                    value="Delete"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Do you want to delete it?...')">
                            </form>
                        </td>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cristianfranco/Documents/university/exams/cristianFranco_exam1/introduction_laravel/resources/views/user/show.blade.php ENDPATH**/ ?>