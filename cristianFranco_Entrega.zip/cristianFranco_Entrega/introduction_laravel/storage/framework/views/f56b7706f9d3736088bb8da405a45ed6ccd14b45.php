<?php $__env->startSection("title"); ?>

<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    <div class="content">
        <div class="title m-b-md">
            Cristian Franco Bedoya
        </div>

        <div class="links">
            <a href="<?php echo e(route('user.create')); ?>">Create User</a>
            <a href="<?php echo e(route('user.index')); ?>">User List</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cristianfranco/Documents/university/introduction_laravel/resources/views/welcome.blade.php ENDPATH**/ ?>