<?php $__env->startSection("title"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-8 mx-auto">

            <table class="table">
                <thead>
                    <tr>
                        <th>Apartamentos</th>
                        <th>Casas</th>
                    </tr>
                </thead>
                <tbody>
                    <td><?php echo e($apartamentos); ?></td>
                    <td><?php echo e($casas); ?></td>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cristianfranco/Documents/university/exams/cristianFranco_exam1/introduction_laravel/resources/views/vivienda/show.blade.php ENDPATH**/ ?>