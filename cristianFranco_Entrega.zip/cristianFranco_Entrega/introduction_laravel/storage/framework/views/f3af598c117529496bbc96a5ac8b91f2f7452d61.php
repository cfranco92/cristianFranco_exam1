<?php $__env->startSection("title"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-8 mx-auto">
            <?php echo $__env->make('util.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card border-0 shadow">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            - <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('users.store')); ?>" method="POST">
                        <div class="form-row">
                            <div class="col-sm-3">
                                <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e(old('name')); ?>">
                            </div>
                            <div class="col-sm-4">
                                <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>
                        <br>
                        <div class="form-row">
                            <div class="col-sm-3">
                                <input type="password" name="password" class="form-control" placeholder="Password">
                            </div>
                            <div class="col-sm-4">
                                <input type="text" name="city" class="form-control" placeholder="City" value="<?php echo e(old('city')); ?>">
                            </div>
                        </div>
                        <br>
                        <div class="form-row">
                            <div class="col-sm-4">
                                <input type="text" name="phone" class="form-control" placeholder="Phone" value="<?php echo e(old('phone')); ?>">
                            </div>
                        </div>
                        <br><br>
                        <div class="form-row center">
                            <div class="col-auto">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cristianfranco/Documents/university/introduction_laravel/resources/views/user/create.blade.php ENDPATH**/ ?>