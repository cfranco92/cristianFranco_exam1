<?php $__env->startSection("title"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-8 mx-auto">

            <table class="table">
                <thead>
                    <tr>
                        <th>Icon</th>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e($user->icon); ?>" alt="User icon" style="width:25px;height:25px;"></td>
                        <?php if($index < 2): ?>
                            <td><b><a href="<?php echo e(route('user.show',['id'=>$user->id])); ?>"><?php echo e($user->id); ?></a></b></td>
                        <?php else: ?>
                            <td><a href="<?php echo e(route('user.show',['id'=>$user->id])); ?>"><?php echo e($user->id); ?></a></td>
                        <?php endif; ?>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route('user.show',['id'=>$user->id])); ?>" class="btn btn-primary btn-sm">VIEW</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cristianfranco/Documents/university/workshops/workshop_1/introduction_laravel/resources/views/user/index.blade.php ENDPATH**/ ?>