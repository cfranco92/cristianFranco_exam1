<?php $__env->startSection("title"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-8 mx-auto">

            <table class="table">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Dirección</th>
                        <th>Tipo</th>
                        <th>Valor comercial</th>
                        
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $viviendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$vivienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($vivienda->getId()); ?></td>
                        <?php if($vivienda->getTipo() == 'apartamento'): ?>
                            <td><b style="color: green;"><?php echo e($vivienda->getDireccion()); ?></b></td>
                        <?php else: ?> 
                            <td><?php echo e($vivienda->getDireccion()); ?></td>
                        <?php endif; ?> 
                        <td><?php echo e($vivienda->getTipo()); ?></td>
                        <td>$<?php echo e($vivienda->getValorComercial()); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cristianfranco/Documents/university/exams/cristianFranco_exam1/introduction_laravel/resources/views/vivienda/index.blade.php ENDPATH**/ ?>