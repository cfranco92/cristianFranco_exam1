<?php $__env->startSection("title"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-8 mx-auto">
            <?php echo $__env->make('util.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card border-0 shadow">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            - <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('viviendas.store')); ?>" method="POST">
                        <div class="form-row">
                            <div class="col-sm-3">
                                <input type="text" name="direccion" class="form-control" placeholder="Direccion" value="<?php echo e(old('direccion')); ?>">
                            </div>
                            <div class="col-sm-4">
                                <input type="text" name="tipo" class="form-control" placeholder="apartamento o vivienda" value="<?php echo e(old('tipo')); ?>">
                            </div>

                            


                        </div>
                        <br>
                        <div class="form-row">
                            <div class="col-sm-4">
                                <input type="text" name="valor_comercial" class="form-control" placeholder="Valor comercial" value="<?php echo e(old('valor_comercial')); ?>">
                            </div>
                        </div>
                        <br>
                        <br><br>
                        <div class="form-row center">
                            <div class="col-auto">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cristianfranco/Documents/university/exams/cristianFranco_exam1/introduction_laravel/resources/views/vivienda/create.blade.php ENDPATH**/ ?>