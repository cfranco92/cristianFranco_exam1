<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>    
    <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
<?php /**PATH /Users/cristianfranco/Documents/university/introduction_laravel/resources/views/util/message.blade.php ENDPATH**/ ?>